import java.util.List;
import java.util.ArrayList;

public class Professor {
    private String nomeCompleto;
    private List<String> disciplinas;
    private List<String> turmasLecionadas;
    private double mediaGlobal = 0.0;           // ✅ ADICIONADO
    private int turmasExcelentesCount = 0;      // ✅ ADICIONADO

    public Professor(String nomeCompleto, List<String> disciplinas, List<String> turmasLecionadas) {
        this.nomeCompleto = nomeCompleto;
        this.disciplinas = disciplinas != null ? disciplinas : new ArrayList<>();
        this.turmasLecionadas = turmasLecionadas != null ? turmasLecionadas : new ArrayList<>();
    }

    public String getNomeCompleto() {
        return nomeCompleto;
    }

    public List<String> getDisciplinas() {
        return disciplinas;
    }

    public List<String> getTurmasLecionadas() {
        return turmasLecionadas;
    }

    public int getQuantidadeDisciplinas() {
        return disciplinas.size();
    }

    public int getQuantidadeTurmas() {
        return turmasLecionadas.size();
    }

    // ✅ CORRIGIDO: Retorna double ao invés de Object
    public double getMediaGlobal() {
        return mediaGlobal;
    }

    // ✅ ADICIONADO
    public int getTurmasExcelentesCount() {
        return turmasExcelentesCount;
    }

    public double calcularMediaGlobalAlunos(List<Aluno> alunos) {
        if (alunos == null || alunos.isEmpty()) {
            return 0.0;
        }

        double somaTotalMedias = 0.0;

        for (Aluno aluno : alunos) {
            double somaMediasBimestrais = aluno.calcularSomaTotalMedias();
            String situacao = aluno.getSituacaoFinal();

            if (situacao.contains("APROVADO (Após Final)") || situacao.contains("REPROVADO (Após Final)")) {
                somaTotalMedias += (somaMediasBimestrais + aluno.getNotaFinal()) / 5.0;
            } else {
                somaTotalMedias += somaMediasBimestrais / 4.0;
            }
        }

        return somaTotalMedias / alunos.size();
    }

    public int contarTurmasExcelentes(List<String> resultadosTurmas) {
        int turmasExcelentes = 0;
        for (String resultado : resultadosTurmas) {
            if (resultado.equals("EXCELENTE")) {
                turmasExcelentes++;
            }
        }
        return turmasExcelentes;
    }

    // ✅ ADICIONADO: Necessário para Main.java
    public void setMediaGlobal(double mediaGlobal) {
        this.mediaGlobal = mediaGlobal;
    }

    // ✅ ADICIONADO: Necessário para Main.java
    public void setTurmasExcelentesCount(int turmasExcelentesCount) {
        this.turmasExcelentesCount = turmasExcelentesCount;
    }
}
