import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Collectors;

public class Main {

    
    
    private static List<Turma> turmas = new ArrayList<>();
    private static List<Professor> professores = new ArrayList<>();
    private static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        scanner.useLocale(java.util.Locale.forLanguageTag("pt-BR"));

        System.out.println("\n--- Sistema Acadêmico ---");
        System.out.println("Gestão de Desempenho e Avaliação Docente");

        menuPrincipal();
        
        System.out.println("\nSistema encerrado.");
        scanner.close();
    }
    
    private static void menuPrincipal() {
        int opcao = -1;
        while (opcao != 0) {
            System.out.println("\n[ MENU PRINCIPAL ]");
            System.out.println("1. Cadastrar Turma");
            System.out.println("2. Cadastrar Professor");
            System.out.println("3. Cadastrar Aluno e Notas");
            System.out.println("4. Relatórios e Rankings");
            System.out.println("0. Sair");
            System.out.print("Opção: ");
            
            try {
                if (scanner.hasNextInt()) {
                    opcao = scanner.nextInt();
                    scanner.nextLine(); 
                } else {
                    scanner.next(); 
                    throw new InputMismatchException();
                }
                
                switch (opcao) {
                    case 1:
                        cadastrarTurmaInterativo();
                        break;
                    case 2:
                        cadastrarProfessorInterativo();
                        break;
                    case 3:
                        cadastrarAlunoInterativo();
                        break;
                    case 4:
                        gerarRelatoriosFinais();
                        break;
                    case 0:
                        System.out.println("Saindo...");
                        break;
                    default:
                        System.err.println("Opção inválida. Escolha um número do menu.");
                }
            } catch (InputMismatchException e) {
                System.err.println("Erro: Entrada inválida. Use apenas números.");
                opcao = -1;
            }
        }
    }
    
    private static void cadastrarTurmaInterativo() {
        System.out.println("\n--- Cadastro de Turma ---");
        System.out.print("Nomenclatura da turma (Ex: 1A, 2B): ");
        String nomenclatura = scanner.nextLine().trim();
        
        if (turmas.stream().anyMatch(t -> t.getNomenclatura().equalsIgnoreCase(nomenclatura))) {
            System.err.println("Turma já existe. Escolha outro nome.");
            return;
        }

        Turma novaTurma = new Turma(nomenclatura);
        turmas.add(novaTurma);
        System.out.println("Turma '" + nomenclatura + "' cadastrada!");
    }

    private static void cadastrarProfessorInterativo() {
        System.out.println("\n--- Cadastro de Professor ---");
        System.out.print("Nome Completo: ");
        String nome = scanner.nextLine().trim();

        List<String> disciplinas = lerListaStrings("Disciplinas (separadas por vírgula): ");
        List<String> turmasLecionadas = lerListaStrings("Turmas em que atua (separadas por vírgula): ");

        Professor novoProfessor = new Professor(nome, disciplinas, turmasLecionadas);
        professores.add(novoProfessor);
        System.out.println("Professor(a) '" + nome + "' cadastrado(a)!");

        for (String nomeTurma : turmasLecionadas) {
            turmas.stream()
                .filter(t -> t.getNomenclatura().equalsIgnoreCase(nomeTurma.trim()))
                .findFirst()
                .ifPresentOrElse(
                    t -> t.adicionarProfessor(novoProfessor),
                    () -> System.err.println("Aviso: Turma '" + nomeTurma + "' não cadastrada. Professor associado parcialmente.")
                );
        }
    }
    
    private static List<String> lerListaStrings(String prompt) {
        System.out.print(prompt);
        String linha = scanner.nextLine();
        return List.of(linha.split(",")).stream()
            .map(String::trim)
            .filter(s -> !s.isEmpty())
            .collect(Collectors.toList());
    }

    private static void cadastrarAlunoInterativo() {
        if (turmas.isEmpty()) {
            System.err.println("Erro: Cadastre uma turma primeiro (Opção 1).");
            return;
        }
        
        System.out.println("\n--- Cadastro de Aluno ---");
        System.out.print("Nome Completo do Aluno: ");
        String nomeAluno = scanner.nextLine().trim();
        
        System.out.println("Turmas: " + turmas.stream().map(Turma::getNomenclatura).collect(Collectors.joining(", ")));
        System.out.print("Turma: ");
        String nomeTurma = scanner.nextLine().trim();
        
        Turma turmaSelecionada = turmas.stream()
            .filter(t -> t.getNomenclatura().equalsIgnoreCase(nomeTurma))
            .findFirst()
            .orElse(null);

        if (turmaSelecionada == null) {
            System.err.println("Erro: Turma '" + nomeTurma + "' não encontrada.");
            return;
        }

        Aluno novoAluno = new Aluno(nomeAluno);
        turmaSelecionada.adicionarAluno(novoAluno);
        System.out.println("Aluno '" + nomeAluno + "' adicionado à Turma '" + nomeTurma + "'.");
        
        inserirNotasInterativo(novoAluno);
    }
    
    private static void inserirNotasInterativo(Aluno aluno) {
        System.out.println("\n--- Notas de " + aluno.getNome().toUpperCase() + " ---");
        
        for (int b = 1; b <= 4; b++) {
            System.out.printf("\n%dº BIMESTRE:\n", b);
            
            if (b >= 3) {
                String escolha;
                while (true) {
                    System.out.println("Notas do " + b + "º Bimestre já estão disponíveis? (I)nserir / (P)ular e Simular");
                    System.out.print("Escolha (I/P): ");
                    escolha = scanner.nextLine().toUpperCase();
                    if (escolha.equals("I") || escolha.equals("P")) {
                        break;
                    } else {
                        System.err.println("Opção inválida. Digite 'I' ou 'P'.");
                    }
                }
                
                if (escolha.equals("P")) {
                    System.out.println("Notas do " + b + "º Bimestre serão simuladas nos relatórios.");
                    continue;
                }
            }
            
            try {
                double n1 = lerNota("1ª Nota (N1)");
                double n2 = lerNota("2ª Nota (N2)");
                double n3 = lerNota("3ª Nota (N3)");
                aluno.setNotasBimestre(b, n1, n2, n3);
                System.out.printf("Média parcial: %.2f\n", aluno.calcularMediaBimestre(b));

            } catch (IllegalArgumentException e) {
                System.err.println("Erro ao salvar notas: " + e.getMessage());
                System.err.println("Repetindo a inserção para o " + b + "º bimestre.");
                b--; 
            }
        }
        
        // Uso da constante da classe Aluno (melhor prática)
        if (aluno.calcularSomaTotalMedias() < Aluno.MEDIA_TOTAL_MINIMA_APROVACAO && aluno.getSituacaoFinal().equals("APTO A FAZER A FINAL")) {
            System.out.printf("\nATENÇÃO: O aluno é apto à Final. Nota mínima necessária (0-10): %.2f\n", aluno.getNotaMinimaFinalNecessaria());
            String escolhaFinal;
            while (true) {
                System.out.print("Deseja Inserir a Nota da Final agora (S/N)? ");
                escolhaFinal = scanner.nextLine().toUpperCase();
                if (escolhaFinal.equals("S") || escolhaFinal.equals("N")) break;
                System.err.println("Opção inválida. Digite S ou N.");
            }
            
            if (escolhaFinal.equals("S")) {
                double notaFinal = lerNota("Nota Final");
                try {
                    aluno.setNotaFinal(notaFinal);
                    System.out.println("Status Final: " + aluno.getSituacaoFinal());
                } catch (IllegalArgumentException e) {
                    System.err.println("Erro ao setar nota final: " + e.getMessage());
                }
            }
        }
    }

    private static double lerNota(String prompt) {
        double nota = -1;
        // Uso das constantes da classe Aluno (melhor prática)
        while (nota < Aluno.NOTA_MINIMA_PERMITIDA || nota > Aluno.NOTA_MAXIMA_PERMITIDA) {
            System.out.printf("   > %s (%.2f a %.2f): ", prompt, Aluno.NOTA_MINIMA_PERMITIDA, Aluno.NOTA_MAXIMA_PERMITIDA);
            try {
                if (scanner.hasNextDouble()) {
                    nota = scanner.nextDouble();
                    scanner.nextLine(); 
                    if (nota < Aluno.NOTA_MINIMA_PERMITIDA || nota > Aluno.NOTA_MAXIMA_PERMITIDA) {
                        System.err.println("Nota fora do intervalo (0,00 a 10,00).");
                    }
                } else {
                    scanner.next(); 
                    throw new InputMismatchException();
                }
            } catch (InputMismatchException e) {
                System.err.println("Erro: Entrada deve ser numérica (use vírgula).");
                nota = -1;
            }
        }
        return nota;
    }

    private static void gerarRelatoriosFinais() {
        if (turmas.isEmpty()) {
            System.err.println("Nenhuma turma cadastrada.");
            return;
        }
        
        System.out.println("\n--- RELATÓRIOS E RANKINGS ---");

        for (Turma turma : turmas) {
            exibirRelatorioTurma(turma);
        }
        
        exibirRankingProfessores();
    }
    
    private static void exibirRelatorioTurma(Turma turma) {
        System.out.println("\n== Turma: " + turma.getNomenclatura() + " ==");
        
        System.out.println("Docentes: " + turma.getProfessores().stream()
            .map(Professor::getNomeCompleto)
            .collect(Collectors.joining(", ")));
        
        System.out.println("Disciplinas: " + turma.getProfessores().stream()
            .flatMap(p -> p.getDisciplinas().stream())
            .distinct()
            .collect(Collectors.joining(", ")));
            
        System.out.println("\n[ Resumo ]");
        System.out.printf("Total de Alunos: %d\n", turma.getAlunos().size());
        System.out.printf("Aprovados Direto: %d\n", turma.contarAlunosAprovados());
        System.out.printf("Aptos à Final: %d\n", turma.contarAlunosParaFinal());
        System.out.printf("Reprovados: %d\n", turma.contarAlunosReprovados());
        
        System.out.printf("Desempenho Geral: %s\n", turma.verificarDesempenhoExcelente());
        
        System.out.printf("Alunos em Risco (Média > 7.00 necessária nos próximos BIMS): %d\n", turma.contarAlunosDeRiscoSimulacao(3));

        System.out.println("\n[ Situação Alunos ]");
        if (turma.getAlunos().isEmpty()) {
            System.out.println("(Nenhum aluno cadastrado.)");
            return;
        }

        for (Aluno aluno : turma.getAlunos()) {
            System.out.printf(" > %s: Pontos: %.2f | Status: %s\n", 
                aluno.getNome(), 
                aluno.calcularSomaTotalMedias(),
                aluno.getSituacaoFinal());
            
            if (aluno.getSituacaoFinal().equals("APTO A FAZER A FINAL")) {
                 System.out.printf("   > Nota Mínima Final: %.2f\n", aluno.getNotaMinimaFinalNecessaria());
            } else if (aluno.getSituacaoFinal().contains("Após Final")) {
                 System.out.printf("   > Nota da Final: %.2f\n", aluno.getNotaFinal());
            }
        }
    }
    
    private static void exibirRankingProfessores() {
        if (professores.isEmpty()) {
            System.err.println("\nNenhum professor cadastrado para ranking.");
            return;
        }
        
        List<Professor> professoresComMedia = new ArrayList<>(professores);
        
        for (Professor professor : professoresComMedia) {
            List<Aluno> todosAlunos = new ArrayList<>();
            List<String> resultadosTurmas = new ArrayList<>();
            
            for (String nomeTurma : professor.getTurmasLecionadas()) {
                turmas.stream()
                    .filter(t -> t.getNomenclatura().equalsIgnoreCase(nomeTurma))
                    .findFirst()
                    .ifPresent(t -> {
                        todosAlunos.addAll(t.getAlunos());
                        resultadosTurmas.add(t.verificarDesempenhoExcelente());
                    });
            }
            
            double mediaGlobal = professor.calcularMediaGlobalAlunos(todosAlunos);
            int turmasExcelentes = professor.contarTurmasExcelentes(resultadosTurmas);
            
            professor.setMediaGlobal(mediaGlobal); 
            professor.setTurmasExcelentesCount(turmasExcelentes);
        }
        
        professoresComMedia.sort(Comparator.comparing(Professor::getMediaGlobal).reversed());
        
        System.out.println("\n== RANKING POR Média Global ==");
        for (int i = 0; i < professoresComMedia.size(); i++) {
            Professor p = professoresComMedia.get(i);
            System.out.printf("%dº %s: Média Global: %.2f\n", 
                i + 1, 
                p.getNomeCompleto(), 
                p.getMediaGlobal());
        }

        professoresComMedia.sort(Comparator.comparing(Professor::getTurmasExcelentesCount).reversed());

        System.out.println("\n== RANKING POR Turmas Excelentes ==");
        for (int i = 0; i < professoresComMedia.size(); i++) {
            Professor p = professoresComMedia.get(i);
             System.out.printf("%dº %s: Turmas Excelentes: %d\n", 
                i + 1, 
                p.getNomeCompleto(), 
                p.getTurmasExcelentesCount());
        }
    }
}