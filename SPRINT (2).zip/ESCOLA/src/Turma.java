import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class Turma {

    private static final double MEDIA_MINIMA_RISCO = 7.00;
    private static final double MEDIA_TOTAL_MINIMA_APROVACAO = 28.00;
    private static final double NOTA_MAXIMA_PERMITIDA = 10.00;

    private final String nomenclatura;
    private final List<Professor> professores;
    private final List<Aluno> alunos;

    public Turma(String nomenclatura) {
        this.nomenclatura = nomenclatura;
        this.professores = new ArrayList<>();
        this.alunos = new ArrayList<>();
    }

    public void adicionarProfessor(Professor professor) {
        this.professores.add(professor);
    }

    public void adicionarAluno(Aluno aluno) {
        this.alunos.add(aluno);
    }

    public int contarAlunosAprovados() {
        return (int) alunos.stream()
                .filter(aluno -> aluno.getSituacaoFinal().startsWith("APROVADO"))
                .count();
    }

    public int contarAlunosParaFinal() {
        return (int) alunos.stream()
                .filter(aluno -> aluno.getSituacaoFinal().equals("APTO A FAZER A FINAL"))
                .count();
    }

    public int contarAlunosReprovados() {
        return (int) alunos.stream()
                .filter(aluno -> aluno.getSituacaoFinal().startsWith("REPROVADO"))
                .count();
    }

    public String verificarDesempenhoExcelente() {
        int totalAlunos = alunos.size();
        if (totalAlunos == 0) return "INDEFINIDO";

        int aprovadosDireto = (int) alunos.stream()
                .filter(aluno -> aluno.getSituacaoFinal().equals("APROVADO"))
                .count();

        if (aprovadosDireto > (totalAlunos / 2.0)) {
            return "EXCELENTE";
        }
        return "REGULAR";
    }

    public int contarAlunosDeRiscoSimulacao(int bimestreAtual) {
        int alunosDeRisco = 0;

        for (Aluno aluno : alunos) {
            double somaMediasObtidas = 0.0;
            int bimestresJaConcluidos = 0;

            for (int i = 1; i < bimestreAtual; i++) {
                double media = aluno.calcularMediaBimestre(i);
                if (media > 0.0) {
                    somaMediasObtidas += media;
                    bimestresJaConcluidos++;
                }
            }

            if (bimestresJaConcluidos < 2) continue;

            double pontuacaoFaltante = MEDIA_TOTAL_MINIMA_APROVACAO - somaMediasObtidas;
            int bimestresRestantes = 4 - bimestresJaConcluidos;

            if (pontuacaoFaltante <= 0.0) continue;

            double mediaMinimaRequerida;

            if (bimestresRestantes == 2) {
                mediaMinimaRequerida = Math.max(0.0, pontuacaoFaltante - NOTA_MAXIMA_PERMITIDA);
            } else if (bimestresRestantes == 1) {
                mediaMinimaRequerida = pontuacaoFaltante;
            } else {
                continue;
            }

            if (mediaMinimaRequerida > MEDIA_MINIMA_RISCO) {
                alunosDeRisco++;
            }
        }
        return alunosDeRisco;
    }

    public String getNomenclatura() {
        return nomenclatura;
    }

    public List<Professor> getProfessores() {
        return professores;
    }

    public List<Aluno> getAlunos() {
        return alunos;
    }
}
