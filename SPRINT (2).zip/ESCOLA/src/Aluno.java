public class Aluno {

    private static final double NOTA_MINIMA_PERMITIDA = 0.00;
    private static final double NOTA_MAXIMA_PERMITIDA = 10.00;
    private static final double MEDIA_TOTAL_MINIMA_APROVACAO = 28.00;
    private static final double PONTUACAO_MINIMA_FINAL = 18.00;
    private static final double PONTUACAO_MAXIMA_FINAL = 27.90;

    private final String nome;
    private final double[][] notasBimestrais;
    private double notaFinal = 0.0;

    public Aluno(String nome) {
        this.nome = nome;
        this.notasBimestrais = new double[4][3];
    }

    public void setNotasBimestre(int bimestre, double n1, double n2, double n3) {
        if (bimestre < 1 || bimestre > 4) {
            throw new IllegalArgumentException("Erro: Bimestre inválido. Deve ser entre 1 e 4.");
        }
        if (!validarNota(n1) || !validarNota(n2) || !validarNota(n3)) {
            throw new IllegalArgumentException("Erro: Todas as notas devem estar entre " + NOTA_MINIMA_PERMITIDA + " e " + NOTA_MAXIMA_PERMITIDA + ".");
        }

        int index = bimestre - 1;
        this.notasBimestrais[index][0] = n1;
        this.notasBimestrais[index][1] = n2;
        this.notasBimestrais[index][2] = n3;
    }

    public void setNotaFinal(double notaFinal) {
        if (!validarNota(notaFinal)) {
            throw new IllegalArgumentException("Erro: Nota Final deve estar entre " + NOTA_MINIMA_PERMITIDA + " e " + NOTA_MAXIMA_PERMITIDA + ".");
        }
        this.notaFinal = notaFinal;
    }

    private boolean validarNota(double nota) {
        return nota >= NOTA_MINIMA_PERMITIDA && nota <= NOTA_MAXIMA_PERMITIDA;
    }

    public double calcularMediaBimestre(int bimestre) {
        if (bimestre < 1 || bimestre > 4) return 0.0;

        int index = bimestre - 1;
        double n1 = notasBimestrais[index][0];
        double n2 = notasBimestrais[index][1];
        double n3 = notasBimestrais[index][2];

        return (n1 + n2 + n3) / 3.0;
    }

    public double calcularSomaTotalMedias() {
        double soma = 0.0;
        for (int i = 1; i <= 4; i++) {
            soma += calcularMediaBimestre(i);
        }
        return soma;
    }

    public String getSituacaoFinal() {
        double somaMedias = calcularSomaTotalMedias();

        if (somaMedias >= MEDIA_TOTAL_MINIMA_APROVACAO) {
            return "APROVADO";
        }

        if (somaMedias >= PONTUACAO_MINIMA_FINAL && somaMedias <= PONTUACAO_MAXIMA_FINAL) {

            double notaMinimaFinalNecessaria = getNotaMinimaFinalNecessaria();

            if (notaMinimaFinalNecessaria > NOTA_MAXIMA_PERMITIDA) {
                return "REPROVADO";
            }

            if (notaFinal > 0.0) {
                if (somaMedias + notaFinal >= MEDIA_TOTAL_MINIMA_APROVACAO) {
                    return "APROVADO (Após Final)";
                } else {
                    return "REPROVADO (Após Final)";
                }
            }

            return "APTO A FAZER A FINAL";
        }

        return "REPROVADO";
    }

    public double getNotaMinimaFinalNecessaria() {
        double somaMedias = calcularSomaTotalMedias();
        double pontuacaoFaltante = MEDIA_TOTAL_MINIMA_APROVACAO - somaMedias;

        return Math.max(0.0, pontuacaoFaltante);
    }

    public String getNome() {
        return nome;
    }

    public double getNotaFinal() {
        return notaFinal;
    }

    public double[][] getNotasBimestrais() {
        return notasBimestrais;
    }
}