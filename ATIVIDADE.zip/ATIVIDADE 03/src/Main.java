import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;
import java.text.DecimalFormat;

public class Main {
    public static void main(String[] args) {
        Scanner leitor = new Scanner(System.in);
        List<Filme> catalogo = new ArrayList<>();

        int opcao;
        System.out.println("--- Plataforma de Streaming ---");

        do {
            System.out.println("\n--- Menu Principal ---");
            System.out.println("1 - Cadastrar Novo Título");
            System.out.println("2 - Exibir Detalhes de um Título");
            System.out.println("3 - Avaliar Título");
            System.out.println("4 - Exibir Média de Avaliação de um Título");
            System.out.println("5 - Sair do Programa");
            System.out.print("Escolha uma opção: ");

            try {
                opcao = leitor.nextInt();
                leitor.nextLine(); // Consome a quebra de linha

                switch (opcao) {
                    case 1:
                        cadastrarTitulo(leitor, catalogo);
                        break;
                    case 2:
                        exibirDetalhesTitulo(leitor, catalogo);
                        break;
                    case 3:
                        avaliarTitulo(leitor, catalogo);
                        break;
                    case 4:
                        exibirMedia(leitor, catalogo);
                        break;
                    case 5:
                        System.out.println("\nEncerrando o programa. Até logo!");
                        break;
                    default:
                        System.out.println("Opção inválida. Tente novamente.");
                }
            } catch (InputMismatchException e) {
                System.out.println("\nERRO: Entrada inválida. Por favor, digite um número para a opção.");
                leitor.nextLine();
                opcao = -1;
            }
        } while (opcao != 5);

        leitor.close();
    }

    // --- Métodos de Apoio ---

    private static void listarTitulos(List<Filme> catalogo) {
        if (catalogo.isEmpty()) {
            System.out.println("O catálogo está vazio. Cadastre um título primeiro.");
            return;
        }
        System.out.println("\n--- Títulos Cadastrados ---");
        for (int i = 0; i < catalogo.size(); i++) {
            System.out.println((i + 1) + ". " + catalogo.get(i).getNome());
        }
        System.out.println("---------------------------");
    }

    private static Filme buscarTitulo(Scanner leitor, List<Filme> catalogo) {
        if (catalogo.isEmpty()) {
            System.out.println("O catálogo está vazio.");
            return null;
        }
        listarTitulos(catalogo);
        System.out.print("Digite o NÚMERO do título que deseja selecionar: ");

        try {
            int indice = leitor.nextInt() - 1;
            leitor.nextLine();

            if (indice >= 0 && indice < catalogo.size()) {
                return catalogo.get(indice);
            } else {
                System.out.println("ERRO: Número de título inválido.");
                return null;
            }
        } catch (InputMismatchException e) {
            System.out.println("ERRO: Digite um número inteiro válido.");
            leitor.nextLine();
            return null;
        }
    }

    private static void cadastrarTitulo(Scanner leitor, List<Filme> catalogo) {
        try {
            System.out.println("\n--- Cadastro de Título ---");
            System.out.print("Nome do Título: ");
            String nome = leitor.nextLine();

            System.out.print("Gênero: ");
            String genero = leitor.nextLine();

            System.out.print("Ano de Lançamento (Ex: 2023): ");
            int ano = leitor.nextInt();

            System.out.print("Duração em minutos (Ex: 125): ");
            int duracao = leitor.nextInt();
            leitor.nextLine();

            Filme novoFilme = new Filme(nome, genero, ano, duracao);
            catalogo.add(novoFilme);
            System.out.println("\nTítulo '" + nome + "' cadastrado com sucesso!");
        } catch (InputMismatchException e) {
            System.out.println("ERRO: Entrada de número inválida. Certifique-se de digitar números inteiros para o ano e duração.");
            leitor.nextLine();
        }
    }

    private static void exibirDetalhesTitulo(Scanner leitor, List<Filme> catalogo) {
        System.out.println("\n--- Exibir Detalhes ---");
        Filme filme = buscarTitulo(leitor, catalogo);
        if (filme != null) {
            filme.exibirDetalhes();
        }
    }

    private static void avaliarTitulo(Scanner leitor, List<Filme> catalogo) {
        System.out.println("\n--- Avaliar Título ---");
        Filme filme = buscarTitulo(leitor, catalogo);
        if (filme != null) {
            try {
                System.out.print("Digite a nota (0 a 10): ");
                int nota = leitor.nextInt();
                leitor.nextLine();
                filme.avaliar(nota);
            } catch (InputMismatchException e) {
                System.out.println("ERRO: Digite um número inteiro para a nota.");
                leitor.nextLine();
            }
        }
    }

    private static void exibirMedia(Scanner leitor, List<Filme> catalogo) {
        System.out.println("\n--- Média de Avaliação ---");
        Filme filme = buscarTitulo(leitor, catalogo);
        if (filme != null) {
            double media = filme.calcularMediaAvaliacoes();
            DecimalFormat df = new DecimalFormat("#.00");

            System.out.println("Média de Avaliação para '" + filme.getNome() + "': " + df.format(media));
        }
    }
}