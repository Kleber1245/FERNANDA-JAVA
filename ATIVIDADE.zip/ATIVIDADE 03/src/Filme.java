import java.text.DecimalFormat;

public class Filme {
    private String nome;
    private String genero;
    private int ano;
    private int duracao; // Duração em minutos
    private double somaNotas;
    private int qtdAvaliacoes;

    public Filme(String nome, String genero, int ano, int duracao) {
        this.nome = nome;
        this.genero = genero;
        this.ano = ano;
        this.duracao = duracao;
        this.somaNotas = 0.0;
        this.qtdAvaliacoes = 0;
    }

    public void exibirDetalhes() {
        System.out.println("---------------------------------");
        System.out.println("Título: " + this.nome);
        System.out.println("Gênero: " + this.genero);
        System.out.println("Ano de Lançamento: " + this.ano);
        System.out.println("Duração: " + this.duracao + " minutos");
        System.out.println("---------------------------------");

        // Exibe a média atual ao exibir os detalhes
        double media = calcularMediaAvaliacoes();
        if (this.qtdAvaliacoes > 0) {
            DecimalFormat df = new DecimalFormat("#.00");
            System.out.println("Avaliação Média: " + df.format(media) + " (" + this.qtdAvaliacoes + " avaliações)");
        } else {
            System.out.println("Nenhuma avaliação registrada.");
        }
        System.out.println("---------------------------------");
    }

    public void avaliar(int nota) {
        if (nota >= 0 && nota <= 10) {
            this.somaNotas += nota;
            this.qtdAvaliacoes++;
            System.out.println("Nota " + nota + " registrada com sucesso!");
        } else {
            System.out.println("ERRO: A nota deve estar entre 0 e 10.");
        }
    }

    public double calcularMediaAvaliacoes() {
        if (this.qtdAvaliacoes == 0) {
            return 0.0;
        }
        return this.somaNotas / this.qtdAvaliacoes;
    }

    // Getters para uso na classe Main
    public String getNome() {
        return nome;
    }
}