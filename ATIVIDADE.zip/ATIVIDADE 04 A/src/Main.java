import java.util.Scanner;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;

public class Main {


    private static LocalDate lerData(Scanner scanner) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        LocalDate data = null;
        while (data == null) {
            System.out.print("Data de Admissão" + " (dd/MM/yyyy): ");
            String dataString = scanner.nextLine();
            try {
                data = LocalDate.parse(dataString, formatter);
            } catch (DateTimeParseException e) {
                System.out.println("Formato de data inválido. Tente novamente (ex: 01/01/2020).");
            }
        }
        return data;
    }


    private static boolean lerSimNao(Scanner scanner, String prompt) {
        String resposta;
        while (true) {
            System.out.print(prompt + " (sim/não): ");
            resposta = scanner.nextLine().trim();
            if (resposta.equalsIgnoreCase("sim") || resposta.equalsIgnoreCase("não")) {
                return resposta.equalsIgnoreCase("sim");
            } else {
                System.out.println("Resposta inválida. Por favor, digite 'sim' ou 'não'.");
            }
        }
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // --- Inserção de dados para Clínico Geral ---
        System.out.println("--- Cadastro de Clínico Geral ---");
        System.out.print("Nome do Clínico Geral: ");
        String nomeCG = scanner.nextLine();
        System.out.print("CRM do Clínico Geral: ");
        String crmCG = scanner.nextLine();

        LocalDate dataAdmissaoCG = lerData(scanner);

        boolean trabalhaHospitalCG = lerSimNao(scanner, "Trabalha no hospital?");
        boolean atendeCasaCG = lerSimNao(scanner, "Atende em casa?");
        boolean possuiAmbulatorioCG = lerSimNao(scanner, "Possui ambulatório próprio?");

        ClinicoGeral clinico = new ClinicoGeral(nomeCG, crmCG, trabalhaHospitalCG, dataAdmissaoCG, atendeCasaCG, possuiAmbulatorioCG);

        System.out.println("\n--- Dados e Ações do Clínico Geral ---");
        System.out.println("Nome: " + clinico.getNome());
        System.out.println("CRM: " + clinico.getCrm());
        System.out.println("Trabalha no Hospital: " + (clinico.isTrabalhaNoHospital() ? "Sim" : "Não"));
        System.out.println("Tempo de Serviço: " + clinico.calcularTempoServico());
        System.out.println("Atende em Casa: " + (clinico.isAtendeEmCasa() ? "Sim" : "Não"));
        System.out.println("Possui Ambulatório: " + (clinico.isPossuiAmbulatorioProprio() ? "Sim" : "Não"));
        clinico.tratarPaciente();
        clinico.receitar();
        clinico.agendarCheckup("Maria Silva");

        System.out.println("\n--- Cadastro de Cirurgião ---");
        System.out.print("Nome do Cirurgião: ");
        String nomeCirurgiao = scanner.nextLine();
        System.out.print("CRM do Cirurgião: ");
        String crmCirurgiao = scanner.nextLine();

        LocalDate dataAdmissaoCirurgiao = lerData(scanner);

        boolean trabalhaHospitalCirurgiao = lerSimNao(scanner, "Trabalha no hospital?");

        int numCirurgias = 0;
        boolean inputValido = false;
        while (!inputValido) {
            System.out.print("Número de cirurgias realizadas: ");
            try {
                numCirurgias = Integer.parseInt(scanner.nextLine());
                inputValido = true;
            } catch (NumberFormatException e) {
                System.out.println("Entrada inválida. Por favor, digite um número inteiro.");
            }
        }

        Cirurgiao cirurgiao = new Cirurgiao(nomeCirurgiao, crmCirurgiao, trabalhaHospitalCirurgiao, dataAdmissaoCirurgiao, numCirurgias);

        System.out.println("\n--- Dados e Ações do Cirurgião ---");
        System.out.println("Nome: " + cirurgiao.getNome());
        System.out.println("CRM: " + cirurgiao.getCrm());
        System.out.println("Trabalha no Hospital: " + (cirurgiao.isTrabalhaNoHospital() ? "Sim" : "Não"));
        System.out.println("Tempo de Serviço: " + cirurgiao.calcularTempoServico());
        System.out.println("Cirurgias Realizadas: " + cirurgiao.getNumeroCirurgiasRealizadas());
        cirurgiao.tratarPaciente();
        cirurgiao.fazerIncisao();
        cirurgiao.prepararSalaCirurgica();

        scanner.close();
    }
}