import java.time.LocalDate;
import java.time.Period;

public class Medico {
    private String nome;
    private String crm;
    private boolean trabalhaNoHospital;
    private LocalDate dataAdmissao; // Nova informação

    public Medico(String nome, String crm, boolean trabalhaNoHospital, LocalDate dataAdmissao) {
        this.nome = nome;
        this.crm = crm;
        this.trabalhaNoHospital = trabalhaNoHospital;
        this.dataAdmissao = dataAdmissao;
    }

    public String getNome() {
        return nome;
    }

    public String getCrm() {
        return crm;
    }

    public boolean isTrabalhaNoHospital() {
        return trabalhaNoHospital;
    }

    public LocalDate getDataAdmissao() {
        return dataAdmissao;
    }

    public void tratarPaciente() {
        System.out.println("O Dr(a). " + nome + " está tratando um paciente.");
    }

    // Novo método: Calcular tempo de serviço
    public String calcularTempoServico() {
        Period periodo = Period.between(dataAdmissao, LocalDate.now());
        return periodo.getYears() + " anos e " + periodo.getMonths() + " meses";
    }
}

class ClinicoGeral extends Medico {
    private boolean atendeEmCasa;
    private boolean possuiAmbulatorioProprio; // Nova informação

    public ClinicoGeral(String nome, String crm, boolean trabalhaNoHospital, LocalDate dataAdmissao, boolean atendeEmCasa, boolean possuiAmbulatorioProprio) {
        super(nome, crm, trabalhaNoHospital, dataAdmissao);
        this.atendeEmCasa = atendeEmCasa;
        this.possuiAmbulatorioProprio = possuiAmbulatorioProprio;
    }

    public boolean isAtendeEmCasa() {
        return atendeEmCasa;
    }

    public boolean isPossuiAmbulatorioProprio() {
        return possuiAmbulatorioProprio;
    }

    public void receitar() {
        System.out.println("O Clínico Geral Dr(a). " + getNome() + " está receitando medicamentos.");
    }

    // Novo método: Agendar check-up
    public void agendarCheckup(String nomePaciente) {
        System.out.println("Clínico Geral " + getNome() + " agendou um check-up preventivo para " + nomePaciente + ".");
    }
}

class Cirurgiao extends Medico {
    private int numeroCirurgiasRealizadas; // Nova informação

    public Cirurgiao(String nome, String crm, boolean trabalhaNoHospital, LocalDate dataAdmissao, int numeroCirurgiasRealizadas) {
        super(nome, crm, trabalhaNoHospital, dataAdmissao);
        this.numeroCirurgiasRealizadas = numeroCirurgiasRealizadas;
    }

    public int getNumeroCirurgiasRealizadas() {
        return numeroCirurgiasRealizadas;
    }

    @Override
    public void tratarPaciente() {
        System.out.println("O Cirurgião Dr(a). " + getNome() + " está avaliando o procedimento cirúrgico.");
    }

    public void fazerIncisao() {
        System.out.println("O Cirurgião Dr(a). " + getNome() + " está realizando uma incisão cirúrgica.");
    }

    // Novo método: Preparar sala cirúrgica
    public void prepararSalaCirurgica() {
        System.out.println("Cirurgião " + getNome() + " está coordenando a preparação da sala de cirurgia.");
    }
}