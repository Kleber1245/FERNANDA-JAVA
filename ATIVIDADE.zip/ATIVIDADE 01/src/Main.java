import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner leitor = new Scanner(System.in);

        System.out.println("--- Cadastro de Funcionário ---");

        // 1. Ler a Matrícula
        System.out.print("Digite a matrícula do funcionário: ");
        int matricula = leitor.nextInt();
        leitor.nextLine(); // Consumir a nova linha após o nextInt()

        // 2. Ler o Nome
        System.out.print("Digite o nome do funcionário: ");
        String nome = leitor.nextLine();

        // 3. Ler o Salário Bruto
        System.out.print("Digite o salário bruto (ex: 5000.00): ");
        double salarioBruto = leitor.nextDouble();

        // Criar o objeto Funcionario
        Funcionario funcionario = new Funcionario(matricula, nome, salarioBruto);

        // Exibir o Contrachque
        System.out.println("\n--- Contrachque Gerado ---");
        funcionario.exibirContracheque();

        leitor.close();
    }
}