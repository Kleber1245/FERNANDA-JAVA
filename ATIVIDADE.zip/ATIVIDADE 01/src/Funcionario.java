import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.Locale;

public class Funcionario {
    private int matricula;
    private String nome;
    private double salarioBruto;

    private static final double ALIQUOTA_INSS = 0.15; // 15%

    public Funcionario(int matricula, String nome, double salarioBruto) {
        this.matricula = matricula;
        this.nome = nome;
        this.salarioBruto = salarioBruto;
    }

    public double calcularInss() {
        return this.salarioBruto * ALIQUOTA_INSS;
    }

    public double calcularSalarioLiquido() {
        return this.salarioBruto - calcularInss();
    }

    public void exibirContracheque() {
        double descontoInss = calcularInss();
        double salarioLiquido = calcularSalarioLiquido();

        // Configura o formato para moeda (R$) com vírgula como separador decimal
        DecimalFormatSymbols symbols = new DecimalFormatSymbols(new Locale("pt", "BR"));
        DecimalFormat df = new DecimalFormat("R$ #,##0.00", symbols);

        System.out.println("Matrícula: " + this.matricula);
        System.out.println("Nome: " + this.nome);
        System.out.println("Salário Bruto: " + df.format(this.salarioBruto));
        System.out.println("Desconto INSS (" + (int)(ALIQUOTA_INSS * 100) + "%): " + df.format(descontoInss));
        System.out.println("Salário Líquido: " + df.format(salarioLiquido));
    }
}