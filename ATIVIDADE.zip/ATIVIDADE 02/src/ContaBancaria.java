import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.Locale;

public class ContaBancaria {
    private int numeroConta;
    private String titular;
    private double saldo;

    // Configuração para formato de moeda brasileira (R$ com vírgula)
    private static final DecimalFormatSymbols SIMBOLOS_PT_BR = new DecimalFormatSymbols(new Locale("pt", "BR"));
    private static final DecimalFormat FORMATO_MOEDA = new DecimalFormat("R$ #,##0.00", SIMBOLOS_PT_BR);

    public ContaBancaria(int numeroConta, String titular) {
        this.numeroConta = numeroConta;
        this.titular = titular;
        this.saldo = 0.0; // Saldo inicial é zero
    }

    public void consultarSaldo() {
        System.out.println("---------------------------------");
        System.out.println("Conta: " + this.numeroConta + " | Titular: " + this.titular);
        System.out.println("SALDO ATUAL: " + FORMATO_MOEDA.format(this.saldo));
        System.out.println("---------------------------------");
    }

    public void depositar(double valor) {
        if (valor > 0) {
            this.saldo += valor;
            System.out.println("\nDepósito de " + FORMATO_MOEDA.format(valor) + " realizado com sucesso.");
            consultarSaldo();
        } else {
            System.out.println("\nERRO: O valor do depósito deve ser positivo.");
        }
    }

    public boolean sacar(double valor) {
        if (valor > 0) {
            if (this.saldo >= valor) {
                this.saldo -= valor;
                System.out.println("\nSaque de " + FORMATO_MOEDA.format(valor) + " realizado com sucesso.");
                consultarSaldo();
                return true;
            } else {
                System.out.println("\nERRO: Saldo insuficiente. Saldo disponível: " + FORMATO_MOEDA.format(this.saldo));
                return false;
            }
        } else {
            System.out.println("\nERRO: O valor do saque deve ser positivo.");
            return false;
        }
    }

    public boolean transferir(ContaBancaria destino, double valor) {
        if (valor > 0) {
            if (this.saldo >= valor) {
                if (this.sacar(valor)) {
                    destino.saldo += valor;
                    System.out.println("Transferência de " + FORMATO_MOEDA.format(valor) + " enviada para a conta " + destino.numeroConta + " (Titular: " + destino.titular + ") com sucesso.");
                    return true;
                }
                return false;
            } else {
                System.out.println("\nERRO: Saldo insuficiente para realizar a transferência de " + FORMATO_MOEDA.format(valor) + ".");
                consultarSaldo();
                return false;
            }
        } else {
            System.out.println("\nERRO: O valor da transferência deve ser positivo.");
            return false;
        }
    }

    public int getNumeroConta() {
        return numeroConta;
    }

    public String getTitular() {
        return titular;
    }
}