import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

public class Main {
    private static int proximoNumeroConta = 1000;

    public static void main(String[] args) {
        Scanner leitor = new Scanner(System.in);
        // Lista para armazenar todas as contas criadas
        List<ContaBancaria> contas = new ArrayList<>();

        // Cria algumas contas iniciais para demonstração
        contas.add(new ContaBancaria(proximoNumeroConta++, "Joao Silva"));
        contas.add(new ContaBancaria(proximoNumeroConta++, "Maria Santos"));

        int opcao;

        System.out.println("--- Bem-vindo ao Sistema Bancário Multi-Conta ---");

        do {
            System.out.println("\n--- Menu Principal ---");
            System.out.println("1 - Criar Nova Conta");
            System.out.println("2 - Acessar Conta Existente (Operações)");
            System.out.println("3 - Listar Todas as Contas");
            System.out.println("0 - Sair do Sistema");
            System.out.print("Escolha uma opção: ");

            try {
                opcao = leitor.nextInt();
                leitor.nextLine(); // Consome a quebra de linha

                switch (opcao) {
                    case 1:
                        criarNovaConta(leitor, contas);
                        break;
                    case 2:
                        acessarConta(leitor, contas);
                        break;
                    case 3:
                        listarContas(contas);
                        break;
                    case 0:
                        System.out.println("\nEncerrando o sistema bancário. Até mais!");
                        break;
                    default:
                        System.out.println("Opção inválida. Tente novamente.");
                }
            } catch (InputMismatchException e) {
                System.out.println("\nERRO: Entrada inválida. Por favor, digite um número para a opção.");
                leitor.nextLine(); // Limpa o buffer do scanner
                opcao = -1;
            }
        } while (opcao != 0);

        leitor.close();
    }

    // --- Métodos de Apoio ---

    private static void criarNovaConta(Scanner leitor, List<ContaBancaria> contas) {
        System.out.println("\n--- Criação de Nova Conta ---");
        System.out.print("Digite o nome do titular: ");
        String nome = leitor.nextLine();

        ContaBancaria novaConta = new ContaBancaria(proximoNumeroConta++, nome);
        contas.add(novaConta);
        System.out.println("\nConta criada com sucesso!");
        System.out.println("Número da Conta: " + novaConta.getNumeroConta() + " | Titular: " + novaConta.getTitular());
        System.out.println("Saldo Inicial: R$ 0,00");
    }

    private static void listarContas(List<ContaBancaria> contas) {
        if (contas.isEmpty()) {
            System.out.println("\nNenhuma conta cadastrada.");
            return;
        }
        System.out.println("\n--- Contas Cadastradas ---");
        for (ContaBancaria conta : contas) {
            System.out.println("Conta: " + conta.getNumeroConta() + " | Titular: " + conta.getTitular());
        }
    }

    private static ContaBancaria buscarContaPorNumero(List<ContaBancaria> contas, int numero) {
        for (ContaBancaria conta : contas) {
            if (conta.getNumeroConta() == numero) {
                return conta;
            }
        }
        return null;
    }

    private static void acessarConta(Scanner leitor, List<ContaBancaria> contas) {
        if (contas.isEmpty()) {
            System.out.println("\nNenhuma conta cadastrada. Crie uma primeiro (Opção 1).");
            return;
        }

        listarContas(contas);
        System.out.print("\nDigite o número da conta que deseja acessar: ");

        try {
            int numConta = leitor.nextInt();
            ContaBancaria contaSelecionada = buscarContaPorNumero(contas, numConta);

            if (contaSelecionada == null) {
                System.out.println("Conta número " + numConta + " não encontrada.");
                return;
            }

            menuOperacoes(leitor, contas, contaSelecionada);

        } catch (InputMismatchException e) {
            System.out.println("ERRO: O número da conta deve ser um valor numérico.");
            leitor.nextLine();
        }
    }

    private static void menuOperacoes(Scanner leitor, List<ContaBancaria> todasAsContas, ContaBancaria contaAtual) {
        int opcao;
        double valor;

        System.out.println("\n--- Operações na Conta " + contaAtual.getNumeroConta() + " (Titular: " + contaAtual.getTitular() + ") ---");

        do {
            System.out.println("\nSelecione a Operação:");
            System.out.println("1 - Consultar Saldo");
            System.out.println("2 - Depositar");
            System.out.println("3 - Sacar");
            System.out.println("4 - Transferir");
            System.out.println("0 - Voltar ao Menu Principal");
            System.out.print("Opção: ");

            try {
                opcao = leitor.nextInt();

                switch (opcao) {
                    case 1:
                        contaAtual.consultarSaldo();
                        break;
                    case 2:
                        System.out.print("Digite o valor para depósito (Exemplo: 500.00): ");
                        valor = leitor.nextDouble();
                        contaAtual.depositar(valor);
                        break;
                    case 3:
                        System.out.print("Digite o valor para saque (Exemplo: 150.75): ");
                        valor = leitor.nextDouble();
                        contaAtual.sacar(valor);
                        break;
                    case 4:
                        // Lógica de Transferência
                        System.out.println("\n--- Transferência ---");
                        listarContas(todasAsContas);
                        System.out.print("Digite o NÚMERO da conta DESTINO: ");
                        int numDestino = leitor.nextInt();

                        ContaBancaria contaDestino = buscarContaPorNumero(todasAsContas, numDestino);

                        if (contaDestino == null) {
                            System.out.println("ERRO: Conta destino não encontrada.");
                            break;
                        }
                        if (contaDestino.getNumeroConta() == contaAtual.getNumeroConta()) {
                            System.out.println("ERRO: Não é possível transferir para a mesma conta.");
                            break;
                        }

                        System.out.print("Digite o valor para transferência (Exemplo: 200.00): ");
                        valor = leitor.nextDouble();

                        contaAtual.transferir(contaDestino, valor);
                        break;
                    case 0:
                        System.out.println("\nVoltando ao Menu Principal...");
                        break;
                    default:
                        System.out.println("Opção inválida na operação.");
                }
            } catch (InputMismatchException e) {
                System.out.println("\nERRO: Entrada inválida. **Use PONTO (.) para valores decimais (Ex: 10.50).**");
                leitor.nextLine(); // Limpa o buffer do scanner
                opcao = -1;
            }
        } while (opcao != 0);
    }
}