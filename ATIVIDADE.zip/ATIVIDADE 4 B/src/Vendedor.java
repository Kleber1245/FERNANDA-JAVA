import java.util.ArrayList;
import java.util.List;

public class Vendedor extends Pessoa {
    private String matricula;
    // O tipo List<Pedido> está correto
    private List<Pedido> pedidosEmitidos;

    public Vendedor(String nome, String matricula) {
        super(nome);
        this.matricula = matricula;
        this.pedidosEmitidos = new ArrayList<>();
    }

    public String getMatricula() {
        return matricula;
    }

    public List<Pedido> getPedidosEmitidos() {
        return pedidosEmitidos;
    }

    public void adicionarPedido(Pedido pedido) {
        this.pedidosEmitidos.add(pedido);
        // Garante a dupla ligação
        if (pedido.getVendedor() != this) {
            pedido.setVendedor(this);
        }
    }

    public void emitirPedido(Pedido pedido) {
        System.out.println("Vendedor " + getNome() + " (Matrícula: " + matricula + ") emitiu o Pedido Nº " + pedido.getNumero() + ".");
        adicionarPedido(pedido);
    }
}