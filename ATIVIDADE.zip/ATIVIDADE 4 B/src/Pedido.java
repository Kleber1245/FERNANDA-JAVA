import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class Pedido {
    private int numero;
    private LocalDate data;
    private double valorTotal;
    private Cliente cliente;
    private Vendedor vendedor;
    private List<ItemPedido> itens;

    // Classe interna estática para representar cada item no pedido
    public static class ItemPedido {
        private String descricao;
        private int quantidade;
        private double valorUnitario;

        public ItemPedido(String descricao, int quantidade, double valorUnitario) {
            this.descricao = descricao;
            this.quantidade = quantidade;
            this.valorUnitario = valorUnitario;
        }

        public String getDescricao() {
            return descricao;
        }

        public int getQuantidade() {
            return quantidade;
        }

        public double getValorUnitario() {
            return valorUnitario;
        }

        public double getSubtotal() {
            return quantidade * valorUnitario;
        }
    }

    public Pedido(int numero, Cliente cliente, Vendedor vendedor) {
        this.numero = numero;
        this.data = LocalDate.now();
        this.cliente = cliente;
        this.vendedor = vendedor;
        this.itens = new ArrayList<>();
        this.valorTotal = 0.0;
    }

    // Método para adicionar um item ao pedido
    public void adicionarItem(String descricao, int quantidade, double valorUnitario) {
        ItemPedido novoItem = new ItemPedido(descricao, quantidade, valorUnitario);
        this.itens.add(novoItem);
        this.valorTotal += novoItem.getSubtotal();
    }

    // Getters
    public int getNumero() {
        return numero;
    }

    public LocalDate getData() {
        return data;
    }

    public double getValorTotal() {
        return valorTotal;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public Vendedor getVendedor() {
        return vendedor;
    }

    public List<ItemPedido> getItens() {
        return itens;
    }

    // Setters
    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    public void setVendedor(Vendedor vendedor) {
        this.vendedor = vendedor;
    }

    @Override
    public String toString() {
        String statusVendedor = (vendedor != null) ? vendedor.getNome() : "Aguardando Emissão";

        return "Pedido Nº " + numero +
                " | Data: " + data +
                " | Valor Total: R$ " + String.format("%.2f", valorTotal) +
                " | Cliente: " + cliente.getNome() +
                " | Vendedor: " + statusVendedor;
    }
}