import java.util.Scanner;

public class Main {


    private static int lerInteiro(Scanner scanner, String prompt) {
        int valor = -1;
        while (valor < 0) {
            System.out.print(prompt);
            try {
                valor = Integer.parseInt(scanner.nextLine());
                if (valor < 0) throw new NumberFormatException();
            } catch (NumberFormatException e) {
                System.out.println("Entrada inválida. Por favor, digite um número inteiro positivo.");
                valor = -1;
            }
        }
        return valor;
    }


    private static double lerDecimal(Scanner scanner, String prompt) {
        double valor = -1.0;
        while (valor < 0.0) {
            System.out.print(prompt);
            try {
                String input = scanner.nextLine().replace(',', '.');
                valor = Double.parseDouble(input);
                if (valor < 0.0) throw new NumberFormatException();
            } catch (NumberFormatException e) {
                System.out.println("Entrada inválida. Por favor, digite um valor monetário positivo.");
                valor = -1.0;
            }
        }
        return valor;
    }


    private static Pedido criarPedidoComItens(Scanner scanner, Cliente cliente, Vendedor vendedor, int numeroPedido) {
        System.out.println("\n--- INSERÇÃO DE ITENS PARA PEDIDO Nº " + numeroPedido + " ---");

        Pedido novoPedido = new Pedido(numeroPedido, cliente, vendedor);
        String continuar = "sim";

        while (continuar.equalsIgnoreCase("sim")) {
            System.out.print("\nDescrição do Item: ");
            String descricao = scanner.nextLine();

            int quantidade = lerInteiro(scanner, "Quantidade: ");
            double valorUnitario = lerDecimal(scanner, "Valor Unitário (R$): ");

            novoPedido.adicionarItem(descricao, quantidade, valorUnitario);

            System.out.print("Adicionar outro item? (sim/não): ");
            continuar = scanner.nextLine();
        }

        // Adiciona o pedido à lista do cliente (e do vendedor se aplicável)
        cliente.adicionarPedido(novoPedido);

        return novoPedido;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // --- 1. Cadastro de Cliente ---
        System.out.println("--- CADASTRO DE CLIENTE ---");
        System.out.print("Nome do Cliente: ");
        String nomeCliente = scanner.nextLine();
        System.out.print("CPF do Cliente: ");
        String cpfCliente = scanner.nextLine();
        Cliente cliente1 = new Cliente(nomeCliente, cpfCliente);

        // --- 2. Cadastro de Vendedor ---
        System.out.println("\n--- CADASTRO DE VENDEDOR ---");
        System.out.print("Nome do Vendedor: ");
        String nomeVendedor = scanner.nextLine();
        System.out.print("Matrícula do Vendedor: ");
        String matriculaVendedor = scanner.nextLine();
        Vendedor vendedor1 = new Vendedor(nomeVendedor, matriculaVendedor);

        // --- 3. Registro de Pedidos com Itens ---

        // Pedido 1
        // Criamos o pedido sem o vendedor, que será atribuído na emissão
        Pedido pedido1 = criarPedidoComItens(scanner, cliente1, null, 1001);
        vendedor1.emitirPedido(pedido1);

        // Pedido 2
        Pedido pedido2 = criarPedidoComItens(scanner, cliente1, null, 1002);
        vendedor1.emitirPedido(pedido2);

        // --- 4. Exibição de Relatórios ---
        System.out.println("\n=============================================");
        System.out.println("--- RELATÓRIOS DETALHADOS ---");

        // Relatório do Cliente (Detalhado)
        System.out.println("\nRELATÓRIO DE PEDIDOS DO CLIENTE: " + cliente1.getNome());
        for (Pedido p : cliente1.getPedidosFeitos()) {
            System.out.println("-> " + p.toString());
            System.out.println("   Detalhes dos Itens:");
            // Para acessar ItemPedido usamos Pedido.ItemPedido
            for (Pedido.ItemPedido item : p.getItens()) {
                System.out.printf("     - %s | Quantidade: %d | V. Unitário: R$ %.2f | Subtotal: R$ %.2f\n",
                        item.getDescricao(),
                        item.getQuantidade(),
                        item.getValorUnitario(),
                        item.getSubtotal());
            }
        }

        // Relatório do Vendedor (Resumido)
        System.out.println("\nRELATÓRIO DE PEDIDOS EMITIDOS PELO VENDEDOR: " + vendedor1.getNome());
        for (Pedido p : vendedor1.getPedidosEmitidos()) {
            System.out.println("  " + p.toString());
        }

        scanner.close();
    }
}