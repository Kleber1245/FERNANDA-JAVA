import java.util.ArrayList;
import java.util.List;

public class Cliente extends Pessoa {
    private String cpf;
    // O tipo List<Pedido> está correto
    private List<Pedido> pedidosFeitos;

    public Cliente(String nome, String cpf) {
        super(nome);
        this.cpf = cpf;
        this.pedidosFeitos = new ArrayList<>();
    }

    public String getCpf() {
        return cpf;
    }

    public List<Pedido> getPedidosFeitos() {
        return pedidosFeitos;
    }

    public void adicionarPedido(Pedido pedido) {
        this.pedidosFeitos.add(pedido);
        // Garante a dupla ligação
        if (pedido.getCliente() != this) {
            pedido.setCliente(this);
        }
    }

    // Este método foi removido na última versão do Pedido.java, mas o mantenho
    // para demonstrar como o cliente interage com o pedido, mesmo que a criação
    // dos itens ocorra no Main.
    public void fazerPedido(Pedido pedido) {
        adicionarPedido(pedido);
        System.out.println("Cliente " + getNome() + " fez o Pedido Nº " + pedido.getNumero() + ".");
    }
}