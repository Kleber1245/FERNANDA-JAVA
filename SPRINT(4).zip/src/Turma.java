import java.util.*;
import java.util.stream.Collectors;

public class Turma {
    public String nomenclatura;
    public List<Aluno> alunos = new ArrayList<>();
    public Map<String, List<Professor>> disciplinasTurma = new HashMap<>();

    public Turma(String nomenclatura) {
        this.nomenclatura = nomenclatura;
    }

    public void vincularProfessorDisciplina(Professor professor, String disciplina) {
        disciplinasTurma.putIfAbsent(disciplina, new ArrayList<>());
        if (!disciplinasTurma.get(disciplina).contains(professor)) {
            disciplinasTurma.get(disciplina).add(professor);
        }
    }

    public void exibirRelatorioCompleto() {
        System.out.println("\n=== TURMA: " + nomenclatura.toUpperCase() + " ===");
        System.out.println("Alunos: " + alunos.size());

        if (disciplinasTurma.isEmpty()) {
            System.out.println("Nenhuma disciplina vinculada.");
            return;
        }

        System.out.println("Disciplinas:");
        for (Map.Entry<String, List<Professor>> entry : disciplinasTurma.entrySet()) {
            String disciplina = entry.getKey();
            String professores = entry.getValue().stream()
                    .map(p -> p.nomeCompleto)
                    .collect(Collectors.joining(", "));
            System.out.println("  ✓ " + disciplina + " (" + professores + ")");
        }

        System.out.println("\n--- DESEMPENHO DOS ALUNOS ---");
        if (alunos.isEmpty()) {
            System.out.println("Nenhum aluno matriculado.");
            return;
        }

        for (Aluno aluno : alunos) {
            System.out.print(aluno.nome + ": ");
            double somaTotal = 0;
            for (String disciplina : disciplinasTurma.keySet()) {
                double media = aluno.calcularMediaGeralDisciplina(disciplina);
                somaTotal += media;
                System.out.printf("%s=%.1f ", disciplina.substring(0, Math.min(3, disciplina.length())), media);
            }
            System.out.printf("| TOTAL=%.1f [%s]\n", somaTotal, aluno.getSituacaoFinal());
        }
    }
}
