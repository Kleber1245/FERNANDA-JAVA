import java.util.*;

public class Aluno {
    public static final double NOTA_MIN = 0.0;
    public static final double NOTA_MAX = 10.0;
    public static final double SOMA_MIN_APROVACAO = 28.0;

    public String nome;
    public Map<String, double[][]> notasPorDisciplina = new HashMap<>(); // disciplina -> [bimestre][notas]

    public Aluno(String nome) {
        this.nome = nome;
    }

    public void setNotasBimestre(int bimestre, String disciplina, double n1, double n2, double n3) {
        if (bimestre < 1 || bimestre > 4) throw new IllegalArgumentException("Bimestre inválido");
        validarNota(n1); validarNota(n2); validarNota(n3);

        notasPorDisciplina.putIfAbsent(disciplina, new double[4][3]);
        double[][] notasDisc = notasPorDisciplina.get(disciplina);
        notasDisc[bimestre-1][0] = n1;
        notasDisc[bimestre-1][1] = n2;
        notasDisc[bimestre-1][2] = n3;
    }

    public double calcularMediaBimestre(int bimestre, String disciplina) {
        if (!notasPorDisciplina.containsKey(disciplina)) return 0.0;
        double[][] notas = notasPorDisciplina.get(disciplina);
        if (bimestre < 1 || bimestre > 4 || notas[bimestre-1][0] == 0) return 0.0;
        return (notas[bimestre-1][0] + notas[bimestre-1][1] + notas[bimestre-1][2]) / 3.0;
    }

    public double calcularMediaGeralDisciplina(String disciplina) {
        if (!notasPorDisciplina.containsKey(disciplina)) return 0.0;
        double soma = 0;
        int count = 0;
        for (int b = 1; b <= 4; b++) {
            double mediaB = calcularMediaBimestre(b, disciplina);
            if (mediaB > 0) {
                soma += mediaB;
                count++;
            }
        }
        return count > 0 ? soma / count : 0.0;
    }

    public String getSituacaoFinal() {
        double somaTotal = 0;
        int disciplinasCount = 0;

        for (String disciplina : notasPorDisciplina.keySet()) {
            double media = calcularMediaGeralDisciplina(disciplina);
            if (media > 0) {
                somaTotal += media;
                disciplinasCount++;
            }
        }

        if (disciplinasCount == 0) return "SEM NOTAS";
        double mediaGeral = somaTotal / disciplinasCount;

        return mediaGeral >= 7.0 ? "APROVADO" :
                somaTotal >= SOMA_MIN_APROVACAO ? "APROVADO" : "REPROVADO";
    }

    private void validarNota(double nota) {
        if (nota < NOTA_MIN || nota > NOTA_MAX) {
            throw new IllegalArgumentException("Nota inválida: " + nota);
        }
    }
}
