import java.util.*;
import java.util.stream.Collectors;

public class Main {
    public static List<Turma> turmas = new ArrayList<>();
    public static List<Professor> professores = new ArrayList<>();
    public static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        scanner.useLocale(Locale.forLanguageTag("pt-BR"));
        System.out.println("\n--- Sistema Acadêmico Completo ---");
        menuPrincipal();
        System.out.println("\nSistema encerrado.");
        scanner.close();
    }

    public static void menuPrincipal() {
        int opcao = -1;
        while (opcao != 0) {
            System.out.println("\n=== MENU PRINCIPAL ===");
            System.out.println("1. Cadastrar Turma");
            System.out.println("2. Cadastrar Professor");
            System.out.println("3. Cadastrar Aluno");
            System.out.println("4. Vincular Professor-Turma-Disciplina");
            System.out.println("5. Inserir Notas Sequenciais");
            System.out.println("6. Relatórios");
            System.out.println("0. Sair");
            System.out.print("Opção: ");

            try {
                opcao = scanner.nextInt();
                scanner.nextLine();
                switch (opcao) {
                    case 1: cadastrarTurma(); break;
                    case 2: cadastrarProfessor(); break;
                    case 3: cadastrarAluno(); break;
                    case 4: vincularProfessorTurma(); break;
                    case 5: inserirNotasSequenciais(); break;
                    case 6: relatorios(); break;
                    case 0: System.out.println("Saindo..."); break;
                    default: System.err.println("Opção inválida.");
                }
            } catch (InputMismatchException e) {
                System.err.println("Digite um número válido.");
                scanner.nextLine();
            }
        }
    }

    public static void cadastrarTurma() {
        System.out.print("Nomenclatura (ex: 1A): ");
        String nome = scanner.nextLine().trim();
        if (turmas.stream().anyMatch(t -> t.nomenclatura.equalsIgnoreCase(nome))) {
            System.err.println("Turma já existe.");
            return;
        }
        turmas.add(new Turma(nome));
        System.out.println("✓ Turma '" + nome + "' criada!");
    }

    public static void cadastrarProfessor() {
        System.out.print("Nome Completo: ");
        String nome = scanner.nextLine().trim();
        System.out.print("Disciplinas (vírgula): ");
        List<String> disciplinas = lerListaStrings();

        Professor professor = new Professor(nome, disciplinas);
        professores.add(professor);
        System.out.println("✓ Professor '" + nome + "' cadastrado!");
    }

    public static void cadastrarAluno() {
        if (turmas.isEmpty()) {
            System.err.println("Cadastre uma turma primeiro!");
            return;
        }

        System.out.println("Turmas: " + turmas.stream().map(t -> t.nomenclatura).collect(Collectors.joining(", ")));
        System.out.print("Turma: ");
        String turmaNome = scanner.nextLine().trim();

        Turma turma = turmas.stream()
                .filter(t -> t.nomenclatura.equalsIgnoreCase(turmaNome))
                .findFirst().orElse(null);

        if (turma == null) {
            System.err.println("Turma não encontrada!");
            return;
        }

        System.out.print("Nome do Aluno: ");
        String nomeAluno = scanner.nextLine().trim();
        Aluno aluno = new Aluno(nomeAluno);
        turma.alunos.add(aluno);
        System.out.println("✓ Aluno '" + nomeAluno + "' matriculado!");
    }

    public static void vincularProfessorTurma() {
        if (turmas.isEmpty() || professores.isEmpty()) {
            System.err.println("Cadastre turmas e professores primeiro!");
            return;
        }

        System.out.println("Professores: " + professores.stream().map(p -> p.nomeCompleto).collect(Collectors.joining(", ")));
        System.out.print("Professor: ");
        String profNome = scanner.nextLine().trim();

        Professor professor = professores.stream()
                .filter(p -> p.nomeCompleto.equalsIgnoreCase(profNome))
                .findFirst().orElse(null);
        if (professor == null) {
            System.err.println("Professor não encontrado!");
            return;
        }

        System.out.println("Turmas: " + turmas.stream().map(t -> t.nomenclatura).collect(Collectors.joining(", ")));
        System.out.print("Turma: ");
        String turmaNome = scanner.nextLine().trim();

        Turma turma = turmas.stream()
                .filter(t -> t.nomenclatura.equalsIgnoreCase(turmaNome))
                .findFirst().orElse(null);
        if (turma == null) {
            System.err.println("Turma não encontrada!");
            return;
        }

        System.out.print("Disciplina: ");
        String disciplina = scanner.nextLine().trim();
        turma.vincularProfessorDisciplina(professor, disciplina);  // LINHA 129 CORRIGIDA
        System.out.println("✓ Professor vinculado à turma/disciplina!");
    }

    public static void inserirNotasSequenciais() {
        if (turmas.isEmpty()) {
            System.err.println("Cadastre turmas primeiro!");
            return;
        }

        System.out.println("Turmas: " + turmas.stream().map(t -> t.nomenclatura).collect(Collectors.joining(", ")));
        System.out.print("Turma: ");
        String turmaNome = scanner.nextLine().trim();
        Turma turma = turmas.stream().filter(t -> t.nomenclatura.equalsIgnoreCase(turmaNome)).findFirst().orElse(null);
        if (turma == null || turma.alunos.isEmpty()) {
            System.err.println("Turma sem alunos!");
            return;
        }

        System.out.println("Alunos: " + turma.alunos.stream().map(a -> a.nome).collect(Collectors.joining(", ")));
        System.out.print("Aluno: ");
        String alunoNome = scanner.nextLine().trim();
        Aluno aluno = turma.alunos.stream().filter(a -> a.nome.equalsIgnoreCase(alunoNome)).findFirst().orElse(null);
        if (aluno == null) {
            System.err.println("Aluno não encontrado!");
            return;
        }

        inserirNotasPorBimestre(turma, aluno);
    }

    public static void inserirNotasPorBimestre(Turma turma, Aluno aluno) {
        for (int bimestre = 1; bimestre <= 4; bimestre++) {
            System.out.printf("\n=== %dº BIMESTRE ===\n", bimestre);

            if (bimestre >= 3) {
                System.out.print("(I)nserir / (S)imular / (P)ular: ");
                String opcao = scanner.nextLine().toUpperCase();
                if (opcao.equals("S")) {
                    simularNotasBimestre(aluno, turma, bimestre);
                    continue;
                }
                if (opcao.equals("P")) continue;
            }

            for (String disciplina : turma.disciplinasTurma.keySet()) {
                System.out.printf("%s - N1/N2/N3: ", disciplina);
                double n1 = lerNotaValidada();
                double n2 = lerNotaValidada();
                double n3 = lerNotaValidada();

                aluno.setNotasBimestre(bimestre, disciplina, n1, n2, n3);
                System.out.printf("✓ Média: %.2f\n", aluno.calcularMediaBimestre(bimestre, disciplina));
            }
        }

        verificarProvaFinal(aluno, turma);
    }

    public static void simularNotasBimestre(Aluno aluno, Turma turma, int bimestre) {
        double somaAnterior = 0;
        for (int b = 1; b < bimestre; b++) {
            for (String disciplina : turma.disciplinasTurma.keySet()) {
                somaAnterior += aluno.calcularMediaBimestre(b, disciplina);
            }
        }
        double minima = bimestre == 3 ? 21.0 : 28.0;
        System.out.printf("Simulação: Soma anterior=%.1f | Mínimo necessário=%.1f\n", somaAnterior, minima);
    }

    public static void verificarProvaFinal(Aluno aluno, Turma turma) {
        double somaTotal = 0;
        for (String disciplina : turma.disciplinasTurma.keySet()) {
            for (int b = 1; b <= 4; b++) {
                somaTotal += aluno.calcularMediaBimestre(b, disciplina);
            }
        }
        if (somaTotal < 28.0) {
            System.out.printf("Prova Final necessária! Soma atual: %.1f\n", somaTotal);
        } else {
            System.out.printf("✓ APROVADO! Soma total: %.1f\n", somaTotal);
        }
    }

    public static double lerNotaValidada() {
        while (true) {
            try {
                double nota = scanner.nextDouble();
                scanner.nextLine();
                if (nota >= 0 && nota <= 10) return nota;
                System.err.println("Nota deve estar entre 0.0 e 10.0");
            } catch (InputMismatchException e) {
                System.err.println("Digite um número válido.");
                scanner.nextLine();
            }
        }
    }

    public static List<String> lerListaStrings() {
        String linha = scanner.nextLine();
        return Arrays.stream(linha.split(","))
                .map(String::trim)
                .filter(s -> !s.isEmpty())
                .collect(Collectors.toList());
    }

    public static void relatorios() {
        if (turmas.isEmpty()) {
            System.err.println("Nenhuma turma cadastrada.");
            return;
        }
        System.out.println("\n=== RELATÓRIOS COMPLETOS ===");
        for (Turma turma : turmas) {
            turma.exibirRelatorioCompleto();
        }
    }
}
