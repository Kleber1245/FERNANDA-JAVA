import java.util.List;

public class Professor {
    public String nomeCompleto;
    public List<String> disciplinasPossiveis;

    public Professor(String nomeCompleto, List<String> disciplinasPossiveis) {
        this.nomeCompleto = nomeCompleto;
        this.disciplinasPossiveis = disciplinasPossiveis;
    }
}
